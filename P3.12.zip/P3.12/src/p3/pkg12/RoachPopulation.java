/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package p3.pkg12;

/**
 *
 * @author Ben
 */
public class RoachPopulation 
{
    private int population;
    
    public RoachPopulation(int initialPopulation)
    {
        population = initialPopulation;
    }
    public int waitForDoubling()
    {
        population = (population * 2);
        return population;
    }
    public int spray()
    {
        population = (((population * 10)/100) + population);
        return population;
    }
    public int getRoaches()
    {
        return population;
    }
}
